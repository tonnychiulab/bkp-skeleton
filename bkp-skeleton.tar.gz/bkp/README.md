# bkp — 跨平台備份工具（專案骨架）

這是討論後產出的 Cargo workspace 骨架，取代原本 fork `rsbackup` 的方案。
詳細架構決策說明見對話紀錄；這裡只放實際操作步驟。

## 目前狀態（誠實說明，不要照單全收）

- `bkp-core`：Backend trait、Manifest/FileEntry、diff 引擎，**含單元測試**，是目前最成熟的部分
- `bkp-backend-local`：本地端 hardlink 快照儲存，`put`/`get`/`delete` 已實作，`list` 還是 TODO（回傳空清單）
- `bkp-backend-cloud`：只有骨架，`unimplemented`，等你要接 WebDAV/S3 時再填
- `bkp-config`：profile/retention 資料結構 + 啟動驗證，已可用
- `bkp-i18n`：zh-TW 為預設語系，已有 zh-TW.yml / en.yml 兩份範例字典
- `bkp-audit`：JSON Lines 稽核輸出，`init()` 需要在 main 裡保留回傳的 guard
- `bkp-cli`：`backup` 指令邏輯較完整；`restore`/`snapshots`/`verify` 是 MVP 實作，還沒處理跨快照鏈還原、還原時的權限保留等細節

**這份程式碼還沒有在真正的 Rust 工具鏈上編譯驗證過**（見下方原因），
拿到你的 LXC 容器後，第一步務必先跑 `cargo build`，把實際的編譯錯誤修完，
不要假設它能直接動。

## 為什麼沒有先幫你編譯確認

開發這份骨架的沙盒環境網路只能透過 apt 裝到 Ubuntu 24.04 內建的 rustc/cargo 1.75，
而目前 crates.io 上不少套件（`clap`、`blake3`、`time` 的相依鏈）已經要求
edition2024（需要 rustc 1.85+），沙盒又連不到 rustup 官方安裝所需的網域，
所以没辦法在那邊裝到夠新的工具鏈完整編譯驗證。這純粹是環境限制，
不代表程式碼邏輯有問題，但也代表你拿到手之後**一定會遇到一些編譯錯誤要修**，
心理上要有準備。

## 在 LXC 容器裡的建置步驟

```bash
# 1. 系統套件（Debian/Ubuntu 系 LXC 容器）
sudo apt update
sudo apt install -y build-essential pkg-config libssl-dev curl git

# 2. 安裝 rustup（會裝到最新穩定版，滿足 edition2024 需求）
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y
source "$HOME/.cargo/env"
rustc --version   # 確認 >= 1.85

# 3. 解壓縮這份骨架
tar xzf bkp-skeleton.tar.gz
cd bkp

# 4. 建置（第一次一定會因為 Cargo.lock 是全新產生而抓取套件，需要網路）
cargo build

# 5. 跑測試（bkp-core / bkp-backend-local / bkp-config 都有單元測試）
cargo test

# 6. 建一份最小設定檔試跑
mkdir -p /tmp/bkp-demo/src /tmp/bkp-demo/dest
echo "hello" > /tmp/bkp-demo/src/hello.txt
cat > bkp.yaml << 'YAML'
profiles:
  - name: demo
    source: /tmp/bkp-demo/src
    destination:
      type: local
      path: /tmp/bkp-demo/dest
    exclude: []
YAML

cargo run --bin bkp -- backup --profile demo
cargo run --bin bkp -- snapshots --profile demo
```

## 已知會踩到的坑（先講在前面）

- `bkp-cli/Cargo.toml` 裡 `time`／`blake3`／`clap` 都用寬鬆版本號（`"1"`、`"4"`），
  第一次 `cargo build` 會抓到當下最新版，如果日後 crates.io 又有新版要求更新的
  edition，記得對照你 LXC 容器裝的 rustc 版本調整。
- `snapshot.rs` 裡用 `time::serde::rfc3339` 序列化時間欄位，需要 `time` crate
  開啟 `serde` feature（workspace Cargo.toml 已經開了，但如果你日後升級版本要注意别拿掉）。
- `LocalBackend::list()` 目前回傳空陣列，`bkp-cli` 沒有依賴它做決策（backup 流程
  是直接讀舊 manifest.json 來比對），但如果你之後要加「校驗 destination 實際內容
  跟 manifest 是否一致」的功能，會需要先把這個補完。
- GPL 授權疑慮已經不存在了（workspace 用 `MIT OR Apache-2.0`），但 `Cargo.toml`
  裡的 `authors`/`repository` 欄位還是佔位符，記得改成你自己的。

## 下一步建議

1. 先讓 `cargo build && cargo test` 全部過
2. 補完 `LocalBackend::list()`
3. 把 `bkp-cli` 的錯誤訊息接上 `bkp-i18n` 的 `t!()` 巨集（目前 CLI 裡的中文字串
   是直接寫死的，還沒真的走 i18n 那一層，這是刻意先求「能動」，i18n 留給你決定
   優先順序）
4. 幫 `bkp-config` 加上 retention 清理邏輯（目前 `RetentionPolicy` 只是資料結構，
   沒有任何程式碼真的去刪超過保留期限的舊快照）
