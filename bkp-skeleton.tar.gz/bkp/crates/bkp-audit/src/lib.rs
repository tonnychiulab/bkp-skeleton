//! bkp-audit
//!
//! 在 tracing 之上包一層，統一輸出為 JSON Lines，方便直接餵給
//! Fluent Bit -> Graylog/OpenSearch 既有管線。
//! 每次備份任務結束時，額外輸出一筆固定 schema 的「稽核摘要」事件，
//! 方便直接在 Graylog 建 dashboard / 告警規則，滿足資通安全管理法
//! 對備份紀錄可追溯性的要求。

use camino::Utf8Path;
use serde::Serialize;
use tracing_appender::non_blocking::WorkerGuard;
use tracing_subscriber::EnvFilter;

/// 初始化全域 tracing subscriber：console（人類可讀）+ 檔案（JSON Lines）雙輸出。
/// 回傳的 `WorkerGuard` 必須保留在呼叫端（例如 main 函式）的整個生命週期，
/// 否則非同步寫入的 log 可能在程式結束前遺失。
pub fn init(log_path: &Utf8Path) -> anyhow::Result<WorkerGuard> {
    if let Some(parent) = log_path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let file = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(log_path.as_std_path())?;
    let (non_blocking, guard) = tracing_appender::non_blocking(file);

    let file_layer = tracing_subscriber::fmt::layer()
        .json()
        .with_current_span(false)
        .with_writer(non_blocking);

    let console_layer = tracing_subscriber::fmt::layer().with_target(false);

    use tracing_subscriber::layer::SubscriberExt;
    use tracing_subscriber::util::SubscriberInitExt;
    tracing_subscriber::registry()
        .with(EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info")))
        .with(console_layer)
        .with(file_layer)
        .try_init()
        .map_err(|e| anyhow::anyhow!("初始化 log 系統失敗: {e}"))?;

    Ok(guard)
}

/// 每次備份任務結束時輸出的稽核摘要，固定 schema，方便 Graylog 側建欄位索引。
#[derive(Debug, Serialize)]
pub struct BackupAuditSummary<'a> {
    pub profile: &'a str,
    #[serde(with = "time::serde::rfc3339")]
    pub started_at: time::OffsetDateTime,
    #[serde(with = "time::serde::rfc3339")]
    pub finished_at: time::OffsetDateTime,
    pub files_added: usize,
    pub files_modified: usize,
    pub files_deleted: usize,
    pub files_unchanged: usize,
    pub errors: Vec<String>,
    pub success: bool,
}

impl<'a> BackupAuditSummary<'a> {
    /// 用 tracing 的 info!/error! 輸出這筆摘要，帶上結構化欄位，
    /// 讓 JSON Lines 輸出裡每個欄位都是獨立可查詢的 key，而不是塞進一句話裡。
    pub fn emit(&self) {
        if self.success {
            tracing::info!(
                profile = self.profile,
                files_added = self.files_added,
                files_modified = self.files_modified,
                files_deleted = self.files_deleted,
                files_unchanged = self.files_unchanged,
                "backup_audit_summary"
            );
        } else {
            tracing::error!(
                profile = self.profile,
                files_added = self.files_added,
                files_modified = self.files_modified,
                files_deleted = self.files_deleted,
                files_unchanged = self.files_unchanged,
                errors = ?self.errors,
                "backup_audit_summary"
            );
        }
    }
}
