//! bkp-backend-cloud
//!
//! 雲端後端骨架。刻意先只放「能編譯、有基本測試、簽章完全符合 Backend trait」的空殼，
//! 這是為了不重蹈原本 rsbackup 的 storage/cloud.rs 覆轍——
//! 那個檔案的 trait 簽章跟定義對不上，而且從未被 mod.rs 引用，是完全沒被編譯進產物的死碼。
//!
//! 之後要接 WebDAV / S3 相容儲存時，只需要把 `unimplemented()` 換成實際的 HTTP client 呼叫，
//! trait 介面本身不需要再變動。

use async_trait::async_trait;
use bkp_core::{Backend, BackendError, ObjectMeta, SnapshotId};
use camino::Utf8Path;

pub struct WebDavBackend {
    #[allow(dead_code)]
    endpoint: String,
}

impl WebDavBackend {
    pub fn new(endpoint: impl Into<String>) -> Self {
        Self {
            endpoint: endpoint.into(),
        }
    }
}

#[async_trait]
impl Backend for WebDavBackend {
    async fn put(&self, _rel_path: &Utf8Path, _data: &[u8]) -> Result<ObjectMeta, BackendError> {
        Err(BackendError::NotImplemented("webdav put"))
    }

    async fn get(
        &self,
        _rel_path: &Utf8Path,
        _version: Option<&SnapshotId>,
    ) -> Result<Vec<u8>, BackendError> {
        Err(BackendError::NotImplemented("webdav get"))
    }

    async fn list(&self) -> Result<Vec<(String, ObjectMeta)>, BackendError> {
        Err(BackendError::NotImplemented("webdav list"))
    }

    async fn delete(&self, _rel_path: &Utf8Path) -> Result<(), BackendError> {
        Err(BackendError::NotImplemented("webdav delete"))
    }

    fn kind(&self) -> &'static str {
        "webdav"
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// 這個測試存在的意義：確保 WebDavBackend 真的實作了完整的 Backend trait
    /// 並且能被編譯——避免重蹈原本 cloud.rs 簽章對不上、根本編不進去的覆轍。
    #[tokio::test]
    async fn compiles_and_returns_not_implemented() {
        let backend = WebDavBackend::new("https://example.com/dav");
        let err = backend.list().await.unwrap_err();
        assert!(matches!(err, BackendError::NotImplemented(_)));
        assert_eq!(backend.kind(), "webdav");
    }
}
