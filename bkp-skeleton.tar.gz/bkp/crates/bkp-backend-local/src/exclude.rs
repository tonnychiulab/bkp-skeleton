//! 排除規則比對，沿用原本 rsbackup util.rs 的邏輯並補上測試。
//! 支援簡單的 glob 風格（用 `*` 當萬用字元），內部轉成 Regex 比對。

use regex::Regex;

pub struct ExcludeSet {
    patterns: Vec<Regex>,
}

impl ExcludeSet {
    pub fn compile(patterns: &[String]) -> Result<Self, String> {
        let compiled = patterns
            .iter()
            .map(|p| {
                let clean = p.trim_end_matches('/');
                let escaped = regex::escape(clean).replace("\\*", ".*");
                Regex::new(&escaped).map_err(|err| format!("排除規則 `{p}` 不是合法的樣式: {err}"))
            })
            .collect::<Result<_, _>>()?;
        Ok(Self { patterns: compiled })
    }

    pub fn is_excluded(&self, path_str: &str, is_dir: bool) -> bool {
        let with_slash = if is_dir {
            format!("{path_str}/")
        } else {
            path_str.to_string()
        };
        self.patterns
            .iter()
            .any(|p| p.is_match(path_str) || (is_dir && p.is_match(&with_slash)))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn wildcard_excludes_matching_files() {
        let set = ExcludeSet::compile(&["*.log".to_string()]).unwrap();
        assert!(set.is_excluded("/var/data/app.log", false));
        assert!(!set.is_excluded("/var/data/app.txt", false));
    }

    #[test]
    fn directory_pattern_matches_with_trailing_slash() {
        let set = ExcludeSet::compile(&["node_modules".to_string()]).unwrap();
        assert!(set.is_excluded("/project/node_modules", true));
    }
}
