//! bkp-backend-local
//!
//! 本地檔案系統（含掛載的 NAS/網路磁碟）的 Backend 實作。
//! 沿用原本 rsbackup 的 walk 目錄／排除規則比對邏輯，但重寫為：
//! - async（用 tokio::task::spawn_blocking 包住阻塞式的檔案 I/O）
//! - 快照儲存改用「manifest.json + hardlink」，未變更的檔案不會重複佔用磁碟空間
//! - 不用 .unwrap()，所有錯誤路徑都回傳 Result

pub mod exclude;
pub mod snapshot_store;
pub mod storage;

pub use storage::LocalBackend;
