//! 快照的實體儲存策略：每次備份在 `<destination>/snapshots/<snapshot_id>/` 下
//! 建立一份目錄結構，其中「未變更」的檔案用 hardlink 指向上一份快照裡的實體檔案，
//! 只有「新增/修改」的檔案才是真正的新副本。
//!
//! 好處：多版本保留不會造成儲存空間隨版本數線性倍增（未變更檔案不佔用額外空間），
//! 這是 borg / restic 都採用的思路的簡化版本。
//! 代價：destination 檔案系統必須支援 hardlink（同一個磁碟分割內）；
//! 若目的地是跨磁碟或不支援 hardlink 的檔案系統（例如某些網路磁碟協定），
//! 這裡的 `link_or_copy` 會自動 fallback 成整份複製。

use bkp_core::BackendError;
use camino::{Utf8Path, Utf8PathBuf};
use std::fs;
use std::io;

pub fn snapshot_dir(destination_root: &Utf8Path, snapshot_id: &str) -> Utf8PathBuf {
    destination_root.join("snapshots").join(snapshot_id)
}

pub fn manifest_path(destination_root: &Utf8Path, snapshot_id: &str) -> Utf8PathBuf {
    snapshot_dir(destination_root, snapshot_id).join("manifest.json")
}

/// 嘗試 hardlink，失敗（例如跨檔案系統）就 fallback 成複製。
pub fn link_or_copy(source: &Utf8Path, dest: &Utf8Path) -> Result<(), BackendError> {
    if let Some(parent) = dest.parent() {
        fs::create_dir_all(parent).map_err(|e| io_err(parent, e))?;
    }
    match fs::hard_link(source, dest) {
        Ok(()) => Ok(()),
        Err(_) => {
            // 常見原因：跨檔案系統、或目的地檔案系統不支援 hardlink。
            // 直接 fallback 成複製，不視為致命錯誤。
            fs::copy(source, dest).map_err(|e| io_err(dest, e))?;
            Ok(())
        }
    }
}

fn io_err(path: &Utf8Path, source: io::Error) -> BackendError {
    BackendError::Io {
        path: path.to_string(),
        source,
    }
}
