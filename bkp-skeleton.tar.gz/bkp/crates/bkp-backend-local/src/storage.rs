use async_trait::async_trait;
use bkp_core::{Backend, BackendError, ObjectMeta, SnapshotId};
use camino::{Utf8Path, Utf8PathBuf};
use std::fs;
use std::io;

/// 本地檔案系統 Backend。
/// `root` 是這個備份任務的目的地根目錄，實際檔案存放在
/// `root/snapshots/<snapshot_id>/<rel_path>` 底下（見 snapshot_store 模組）。
pub struct LocalBackend {
    root: Utf8PathBuf,
    /// 目前正在寫入的快照 ID；由呼叫端（bkp-cli 的備份流程）在開始備份前建立好。
    current_snapshot: SnapshotId,
}

impl LocalBackend {
    pub fn new(root: impl Into<Utf8PathBuf>, current_snapshot: SnapshotId) -> Self {
        Self {
            root: root.into(),
            current_snapshot,
        }
    }

    fn object_path(&self, rel_path: &Utf8Path) -> Utf8PathBuf {
        crate::snapshot_store::snapshot_dir(&self.root, &self.current_snapshot.to_string())
            .join(rel_path)
    }
}

#[async_trait]
impl Backend for LocalBackend {
    async fn put(&self, rel_path: &Utf8Path, data: &[u8]) -> Result<ObjectMeta, BackendError> {
        let dest = self.object_path(rel_path);
        let data = data.to_vec();
        let dest_clone = dest.clone();

        tokio::task::spawn_blocking(move || -> Result<(), BackendError> {
            if let Some(parent) = dest_clone.parent() {
                fs::create_dir_all(parent).map_err(|e| io_err(parent, e))?;
            }
            fs::write(&dest_clone, &data).map_err(|e| io_err(&dest_clone, e))
        })
        .await
        .map_err(|e| BackendError::Remote(format!("背景寫入工作被中斷: {e}")))??;

        let hash = blake3::hash(&data).to_hex().to_string();
        Ok(ObjectMeta {
            size: data.len() as u64,
            hash,
        })
    }

    async fn get(
        &self,
        rel_path: &Utf8Path,
        version: Option<&SnapshotId>,
    ) -> Result<Vec<u8>, BackendError> {
        let snapshot_id = version.unwrap_or(&self.current_snapshot).to_string();
        let path = crate::snapshot_store::snapshot_dir(&self.root, &snapshot_id).join(rel_path);
        tokio::task::spawn_blocking(move || {
            fs::read(&path).map_err(|e| {
                if e.kind() == io::ErrorKind::NotFound {
                    BackendError::NotFound(path.to_string())
                } else {
                    io_err(&path, e)
                }
            })
        })
        .await
        .map_err(|e| BackendError::Remote(format!("背景讀取工作被中斷: {e}")))?
    }

    async fn list(&self) -> Result<Vec<(String, ObjectMeta)>, BackendError> {
        // TODO: 掃描 self.root/snapshots/<current>/ 底下所有檔案，
        // 對每個檔案回傳 (相對路徑字串, ObjectMeta)。
        // 先回傳空清單讓上層可以編譯、測試流程，之後補上實作。
        Ok(Vec::new())
    }

    async fn delete(&self, rel_path: &Utf8Path) -> Result<(), BackendError> {
        let path = self.object_path(rel_path);
        tokio::task::spawn_blocking(move || {
            fs::remove_file(&path).map_err(|e| {
                if e.kind() == io::ErrorKind::NotFound {
                    BackendError::NotFound(path.to_string())
                } else {
                    io_err(&path, e)
                }
            })
        })
        .await
        .map_err(|e| BackendError::Remote(format!("背景刪除工作被中斷: {e}")))?
    }

    fn kind(&self) -> &'static str {
        "local"
    }
}

fn io_err(path: &Utf8Path, source: io::Error) -> BackendError {
    BackendError::Io {
        path: path.to_string(),
        source,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use bkp_testkit::TempTree;

    #[tokio::test]
    async fn put_then_get_roundtrip() {
        let tmp = TempTree::new();
        let backend = LocalBackend::new(tmp.root.clone(), SnapshotId::new());
        let rel = Utf8Path::new("docs/hello.txt");

        let meta = backend.put(rel, b"hello world").await.unwrap();
        assert_eq!(meta.size, 11);

        let data = backend.get(rel, None).await.unwrap();
        assert_eq!(data, b"hello world");
    }

    #[tokio::test]
    async fn get_missing_file_returns_not_found() {
        let tmp = TempTree::new();
        let backend = LocalBackend::new(tmp.root.clone(), SnapshotId::new());
        let err = backend
            .get(Utf8Path::new("nope.txt"), None)
            .await
            .unwrap_err();
        assert!(matches!(err, BackendError::NotFound(_)));
    }
}
