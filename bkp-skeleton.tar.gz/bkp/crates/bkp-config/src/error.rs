use thiserror::Error;

#[derive(Debug, Error)]
pub enum ConfigError {
    #[error("read config file {path} failed: {source}")]
    Read {
        path: String,
        #[source]
        source: std::io::Error,
    },

    #[error("parse config file {path} failed: {source}")]
    Parse {
        path: String,
        #[source]
        source: serde_yaml::Error,
    },

    #[error("profile `{0}` 驗證失敗: {1}")]
    Invalid(String, String),

    #[error("找不到名為 `{0}` 的 profile")]
    ProfileNotFound(String),
}
