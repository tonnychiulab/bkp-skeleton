//! bkp-config
//!
//! 設定檔格式與驗證。比原本 rsbackup 單一 config.yaml 更進一步：
//! - 支援多個 profile（類似 restic 的 profile 概念），可以同時管理好幾組備份任務
//! - 加入 retention（保留策略），而不是原本「永遠只保留最新一份」的覆蓋式備份
//! - 啟動時就驗證路徑存在、目的地可寫入，不要等跑到一半才發現設定錯誤

pub mod error;
pub mod profile;
pub mod validate;

pub use error::ConfigError;
pub use profile::{DestinationSpec, Hooks, Profile, RetentionPolicy, RootConfig};

use camino::Utf8Path;

/// 讀取並解析設定檔，回傳整份 RootConfig（尚未驗證個別 profile）。
pub fn load(path: &Utf8Path) -> Result<RootConfig, ConfigError> {
    let content = std::fs::read_to_string(path).map_err(|e| ConfigError::Read {
        path: path.to_string(),
        source: e,
    })?;
    serde_yaml::from_str(&content).map_err(|e| ConfigError::Parse {
        path: path.to_string(),
        source: e,
    })
}
