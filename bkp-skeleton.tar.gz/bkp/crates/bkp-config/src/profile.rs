use camino::Utf8PathBuf;
use serde::{Deserialize, Serialize};

/// 整份設定檔的根節點：可以同時定義多個 profile。
#[derive(Debug, Serialize, Deserialize)]
pub struct RootConfig {
    #[serde(default)]
    pub profiles: Vec<Profile>,
}

impl RootConfig {
    pub fn find(&self, name: &str) -> Option<&Profile> {
        self.profiles.iter().find(|p| p.name == name)
    }
}

/// 一組獨立的備份任務設定，對應 CLI 的 `--profile <name>`。
#[derive(Debug, Serialize, Deserialize)]
pub struct Profile {
    pub name: String,
    pub source: Utf8PathBuf,
    pub destination: DestinationSpec,
    #[serde(default)]
    pub exclude: Vec<String>,
    #[serde(default)]
    pub retention: RetentionPolicy,
    /// cron 表達式；先解析存起來，實際排程交給外部
    /// systemd timer（Linux/LXC）或 Windows Task Scheduler，
    /// 這裡不內建常駐排程器，避免又是一個需要顧的長駐行程。
    pub schedule: Option<String>,
    #[serde(default)]
    pub hooks: Hooks,
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "lowercase")]
pub enum DestinationSpec {
    Local { path: Utf8PathBuf },
    WebDav { url: String },
}

/// 保留策略：取代原本 rsbackup「永遠只保留最新一份」的覆蓋式備份。
#[derive(Debug, Serialize, Deserialize)]
pub struct RetentionPolicy {
    #[serde(default = "default_keep_daily")]
    pub keep_daily: u32,
    #[serde(default = "default_keep_weekly")]
    pub keep_weekly: u32,
}

fn default_keep_daily() -> u32 {
    7
}
fn default_keep_weekly() -> u32 {
    4
}

impl Default for RetentionPolicy {
    fn default() -> Self {
        Self {
            keep_daily: default_keep_daily(),
            keep_weekly: default_keep_weekly(),
        }
    }
}

#[derive(Debug, Default, Serialize, Deserialize)]
pub struct Hooks {
    pub pre_backup: Option<String>,
    pub after_backup: Option<String>,
}
