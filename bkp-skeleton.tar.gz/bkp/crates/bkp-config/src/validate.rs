//! 啟動時驗證，不要等備份跑到一半才發現設定錯誤。

use crate::error::ConfigError;
use crate::profile::{DestinationSpec, Profile};

pub fn validate_profile(profile: &Profile) -> Result<(), ConfigError> {
    if !profile.source.exists() {
        return Err(ConfigError::Invalid(
            profile.name.clone(),
            format!("來源目錄不存在: {}", profile.source),
        ));
    }
    if !profile.source.is_dir() {
        return Err(ConfigError::Invalid(
            profile.name.clone(),
            format!("來源路徑不是目錄: {}", profile.source),
        ));
    }
    match &profile.destination {
        DestinationSpec::Local { path } => {
            if let Some(parent) = path.parent() {
                if !parent.exists() {
                    return Err(ConfigError::Invalid(
                        profile.name.clone(),
                        format!("目的地上層目錄不存在: {parent}"),
                    ));
                }
            }
        }
        DestinationSpec::WebDav { url } => {
            if url.is_empty() {
                return Err(ConfigError::Invalid(
                    profile.name.clone(),
                    "WebDAV 目的地網址不可為空".to_string(),
                ));
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::profile::{Hooks, RetentionPolicy};
    use bkp_testkit::TempTree;

    #[test]
    fn rejects_missing_source() {
        let profile = Profile {
            name: "test".into(),
            source: "/definitely/does/not/exist".into(),
            destination: DestinationSpec::Local { path: "/tmp".into() },
            exclude: vec![],
            retention: RetentionPolicy::default(),
            schedule: None,
            hooks: Hooks::default(),
        };
        assert!(validate_profile(&profile).is_err());
    }

    #[test]
    fn accepts_valid_local_profile() {
        let tmp = TempTree::new();
        tmp.write_file("dummy.txt", b"x");
        let profile = Profile {
            name: "test".into(),
            source: tmp.root.clone(),
            destination: DestinationSpec::Local {
                path: tmp.root.join("dest"),
            },
            exclude: vec![],
            retention: RetentionPolicy::default(),
            schedule: None,
            hooks: Hooks::default(),
        };
        assert!(validate_profile(&profile).is_ok());
    }
}
