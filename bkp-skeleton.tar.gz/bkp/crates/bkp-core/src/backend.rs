use crate::error::BackendError;
use crate::snapshot::SnapshotId;
use async_trait::async_trait;
use camino::Utf8Path;
use serde::{Deserialize, Serialize};

/// 儲存後端寫入一個物件後回傳的中繼資料，會被記錄進 Manifest。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ObjectMeta {
    pub size: u64,
    pub hash: String, // blake3 hex string
}

/// 所有儲存後端（本地磁碟、WebDAV、S3 相容儲存……）都要實作這個 trait。
///
/// 設計原則：
/// - 一開始就是 async，即使 LocalBackend 內部用 `tokio::fs`／blocking pool 包一層也沒關係，
///   避免將來要接雲端 API 時整層介面要重新設計。
/// - `put`／`get` 都用相對路徑（`Utf8Path`），Backend 自己知道 root 在哪裡。
/// - 不在 trait 裡定義「怎麼掃描來源目錄」，那是呼叫端（bkp-cli 或未來的排程器）的責任；
///   Backend 只負責「儲存」與「讀取」，維持單一職責。
#[async_trait]
pub trait Backend: Send + Sync {
    /// 寫入一個檔案內容到目的地，回傳寫入後的中繼資料（供 manifest 記錄）。
    async fn put(&self, rel_path: &Utf8Path, data: &[u8]) -> Result<ObjectMeta, BackendError>;

    /// 讀取指定版本的檔案內容；`version` 為 `None` 時讀取最新版本。
    /// 用於還原（restore）流程。
    async fn get(
        &self,
        rel_path: &Utf8Path,
        version: Option<&SnapshotId>,
    ) -> Result<Vec<u8>, BackendError>;

    /// 列出目的地目前已儲存的物件與其 hash，
    /// 供 diff 引擎決定「這個檔案要不要重新傳輸」。
    async fn list(&self) -> Result<Vec<(String, ObjectMeta)>, BackendError>;

    /// 刪除指定物件（用於 retention policy 清理舊快照時）。
    async fn delete(&self, rel_path: &Utf8Path) -> Result<(), BackendError>;

    /// 後端種類名稱，用於 log 與設定檔對應（"local" / "webdav" / "s3" ...）。
    fn kind(&self) -> &'static str;
}
