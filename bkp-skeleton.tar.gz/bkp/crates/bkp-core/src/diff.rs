//! diff 引擎：比對「這次掃描到的檔案樹」跟「上一份 manifest」，
//! 決定每個檔案的 ChangeKind，讓呼叫端知道哪些檔案真的需要重新傳輸。
//!
//! 設計重點（相對於原本 rsbackup 的教訓）：
//! 原本的做法是「來源」跟「目的地」都各自重新算一次完整檔案的 hash 再比較，
//! 大檔案、大量檔案時 I/O 成本很高。這裡的策略分兩階段：
//! 1. 先比對 size + mtime，兩者都相同就直接判定 Unchanged，不必算 hash。
//! 2. 只有 size 或 mtime 對不上時，才需要（由呼叫端）實際讀檔算 blake3 hash 來確認。
//!
//! 這個模組本身不做任何檔案 I/O，只做「已知資訊」的比對邏輯，方便單元測試。

use crate::snapshot::{ChangeKind, FileEntry, Manifest};
use camino::Utf8PathBuf;
use std::collections::HashMap;
use time::OffsetDateTime;

/// 呼叫端掃描檔案系統後，對每個檔案提供的「候選」資訊。
/// hash 欄位為 Option：先給 None（代表尚未算過），
/// diff 引擎判斷需要精確比對時才要求呼叫端補算。
pub struct ScannedFile {
    pub rel_path: Utf8PathBuf,
    pub size: u64,
    pub mtime: OffsetDateTime,
}

/// 比對結果：這個檔案初步判定的狀態，以及是否「需要」算 hash 才能確認。
pub enum DiffOutcome {
    /// size + mtime 都相同，直接視為未變更，不需要算 hash。
    UnchangedFast,
    /// size 或 mtime 不同，或是新檔案，需要呼叫端算出 hash 後再確認一次。
    NeedsHashCheck,
}

/// 對單一掃描到的檔案，依上一份 manifest 判斷初步結果。
pub fn quick_diff(scanned: &ScannedFile, previous: Option<&FileEntry>) -> DiffOutcome {
    match previous {
        Some(prev) if prev.size == scanned.size && prev.mtime == scanned.mtime => {
            DiffOutcome::UnchangedFast
        }
        _ => DiffOutcome::NeedsHashCheck,
    }
}

/// 在呼叫端算出 hash 後，產生最終的 FileEntry。
pub fn finalize_entry(
    scanned: ScannedFile,
    hash: String,
    previous: Option<&FileEntry>,
) -> FileEntry {
    let change = match previous {
        None => ChangeKind::Added,
        Some(prev) if prev.hash == hash => ChangeKind::Unchanged,
        Some(_) => ChangeKind::Modified,
    };
    FileEntry {
        rel_path: scanned.rel_path,
        size: scanned.size,
        hash,
        mtime: scanned.mtime,
        change,
    }
}

/// 比對「這次所有掃描到的檔案」跟「上一份 manifest」，
/// 找出在上一份存在、但這次沒掃到的檔案 -> 視為 Deleted。
/// 呼叫端應該把這些 Deleted 條目一併加進新的 Manifest，
/// 這樣才能在還原時知道「這個時間點之後，哪些檔案曾經被刪除」。
pub fn find_deleted(
    scanned_paths: &[Utf8PathBuf],
    previous: Option<&Manifest>,
) -> Vec<FileEntry> {
    let Some(previous) = previous else {
        return Vec::new();
    };
    let scanned_set: HashMap<&Utf8PathBuf, ()> =
        scanned_paths.iter().map(|p| (p, ())).collect();

    previous
        .entries
        .iter()
        .filter(|e| e.change != ChangeKind::Deleted && !scanned_set.contains_key(&e.rel_path))
        .map(|e| FileEntry {
            rel_path: e.rel_path.clone(),
            size: e.size,
            hash: e.hash.clone(),
            mtime: e.mtime,
            change: ChangeKind::Deleted,
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    fn ts(seconds: i64) -> OffsetDateTime {
        OffsetDateTime::from_unix_timestamp(seconds).unwrap()
    }

    #[test]
    fn unchanged_when_size_and_mtime_match() {
        let prev = FileEntry {
            rel_path: "a.txt".into(),
            size: 100,
            hash: "deadbeef".into(),
            mtime: ts(1000),
            change: ChangeKind::Unchanged,
        };
        let scanned = ScannedFile {
            rel_path: "a.txt".into(),
            size: 100,
            mtime: ts(1000),
        };
        assert!(matches!(
            quick_diff(&scanned, Some(&prev)),
            DiffOutcome::UnchangedFast
        ));
    }

    #[test]
    fn needs_hash_check_when_mtime_differs() {
        let prev = FileEntry {
            rel_path: "a.txt".into(),
            size: 100,
            hash: "deadbeef".into(),
            mtime: ts(1000),
            change: ChangeKind::Unchanged,
        };
        let scanned = ScannedFile {
            rel_path: "a.txt".into(),
            size: 100,
            mtime: ts(2000),
        };
        assert!(matches!(
            quick_diff(&scanned, Some(&prev)),
            DiffOutcome::NeedsHashCheck
        ));
    }

    #[test]
    fn new_file_is_added() {
        let scanned = ScannedFile {
            rel_path: "new.txt".into(),
            size: 10,
            mtime: ts(1000),
        };
        let entry = finalize_entry(scanned, "hash1".into(), None);
        assert_eq!(entry.change, ChangeKind::Added);
    }

    #[test]
    fn deleted_file_detected() {
        let prev_manifest = Manifest {
            snapshot_id: crate::snapshot::SnapshotId::new(),
            created_at: ts(1000),
            source_root: "/src".into(),
            parent: None,
            entries: vec![FileEntry {
                rel_path: "gone.txt".into(),
                size: 5,
                hash: "h".into(),
                mtime: ts(1000),
                change: ChangeKind::Unchanged,
            }],
        };
        let deleted = find_deleted(&[], Some(&prev_manifest));
        assert_eq!(deleted.len(), 1);
        assert_eq!(deleted[0].change, ChangeKind::Deleted);
    }
}
