use thiserror::Error;

/// 所有 Backend 實作共用的錯誤型別。
/// 刻意用明確的 enum 而不是 `Box<dyn Error>`，
/// 讓呼叫端（例如 bkp-cli）可以依錯誤種類決定要重試、跳過還是中止。
#[derive(Debug, Error)]
pub enum BackendError {
    #[error("io error on {path}: {source}")]
    Io {
        path: String,
        #[source]
        source: std::io::Error,
    },

    #[error("object not found: {0}")]
    NotFound(String),

    #[error("permission denied: {0}")]
    PermissionDenied(String),

    #[error("backend feature not implemented yet: {0}")]
    NotImplemented(&'static str),

    #[error("checksum mismatch for {path}: expected {expected}, got {actual}")]
    ChecksumMismatch {
        path: String,
        expected: String,
        actual: String,
    },

    #[error("remote/network error: {0}")]
    Remote(String),
}
