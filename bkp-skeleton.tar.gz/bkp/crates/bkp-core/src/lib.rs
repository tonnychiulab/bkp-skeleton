//! bkp-core
//!
//! 核心抽象層：不碰任何實體檔案系統、不碰設定檔格式、不碰語系字串。
//! 只定義 `Backend` trait 與快照（snapshot）相關的資料結構與 diff 邏輯。
//! 這一層是整個系統中最值得投入測試的地方，因為所有其他 crate 都依賴它，
//! 而它本身不依賴任何其他 crate。

pub mod backend;
pub mod diff;
pub mod error;
pub mod snapshot;

pub use backend::{Backend, ObjectMeta};
pub use error::BackendError;
pub use snapshot::{ChangeKind, FileEntry, Manifest, SnapshotId};
