use camino::Utf8PathBuf;
use serde::{Deserialize, Serialize};
use time::OffsetDateTime;
use uuid::Uuid;

/// 快照的唯一識別碼。用 UUID 而不是純時間戳，
/// 避免同一秒內觸發兩次備份時發生碰撞。
#[derive(Debug, Clone, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct SnapshotId(pub Uuid);

impl SnapshotId {
    pub fn new() -> Self {
        Self(Uuid::new_v4())
    }
}

impl Default for SnapshotId {
    fn default() -> Self {
        Self::new()
    }
}

impl std::fmt::Display for SnapshotId {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.0)
    }
}

/// 單一檔案在某次快照中的狀態。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileEntry {
    pub rel_path: Utf8PathBuf,
    pub size: u64,
    pub hash: String, // blake3 hex string
    #[serde(with = "time::serde::rfc3339")]
    pub mtime: OffsetDateTime,
    pub change: ChangeKind,
}

/// 這個檔案相對於「上一份快照」的變化種類。
/// 用來決定：要不要重新傳輸、要不要在還原時建立 hardlink 指到舊版本。
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ChangeKind {
    Added,
    Modified,
    Unchanged,
    Deleted,
}

/// 一次備份任務產生的完整清單。
/// `parent` 指向上一份快照，形成鏈狀歷史，
/// 這是支援「保留多版本、還原到指定時間點」的核心資料結構。
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Manifest {
    pub snapshot_id: SnapshotId,
    #[serde(with = "time::serde::rfc3339")]
    pub created_at: OffsetDateTime,
    pub source_root: Utf8PathBuf,
    pub entries: Vec<FileEntry>,
    pub parent: Option<SnapshotId>,
}

impl Manifest {
    pub fn new(source_root: Utf8PathBuf, parent: Option<SnapshotId>) -> Self {
        Self {
            snapshot_id: SnapshotId::new(),
            created_at: OffsetDateTime::now_utc(),
            source_root,
            entries: Vec::new(),
            parent,
        }
    }

    /// 這次快照裡實際有變動（新增／修改／刪除）的檔案數，
    /// 用於稽核摘要輸出，不含 Unchanged。
    pub fn changed_count(&self) -> usize {
        self.entries
            .iter()
            .filter(|e| e.change != ChangeKind::Unchanged)
            .count()
    }
}
