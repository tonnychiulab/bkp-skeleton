//! bkp-i18n
//!
//! 所有面向使用者的輸出字串（CLI 提示、錯誤訊息、log 摘要）都應該透過
//! `bkp_i18n::t!("backup.started", name = profile_name)` 這種 key 呼叫，
//! 不要在商業邏輯裡直接寫死字串。
//!
//! zh-TW 為預設語系；語系判斷順序：環境變數 BKP_LANG > LANG > 預設 zh-TW。

rust_i18n::i18n!("locales", fallback = "zh-TW");

pub fn init_locale() {
    let locale = std::env::var("BKP_LANG")
        .or_else(|_| std::env::var("LANG"))
        .unwrap_or_else(|_| "zh-TW".to_string());

    // LANG 環境變數在 Linux 上常見格式是 zh_TW.UTF-8，需要正規化成 zh-TW 才對得上 locale 檔名。
    let normalized = normalize_locale(&locale);
    rust_i18n::set_locale(&normalized);
}

fn normalize_locale(raw: &str) -> String {
    let lang_part = raw.split('.').next().unwrap_or(raw);
    let lang_part = lang_part.replace('_', "-");
    match lang_part.as_str() {
        s if s.starts_with("zh-TW") || s.starts_with("zh-Hant") => "zh-TW".to_string(),
        s if s.starts_with("en") => "en".to_string(),
        _ => "zh-TW".to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn normalizes_linux_style_locale() {
        assert_eq!(normalize_locale("zh_TW.UTF-8"), "zh-TW");
        assert_eq!(normalize_locale("en_US.UTF-8"), "en");
        assert_eq!(normalize_locale("ja_JP.UTF-8"), "zh-TW"); // 尚未支援日文，fallback
    }
}
