//! bkp-testkit
//!
//! 共用測試 fixture：產生暫存目錄、假檔案樹，
//! 讓 bkp-core / bkp-backend-local 等 crate 的整合測試不用各自複製貼上這段樣板程式碼。
//! 這個 crate 只出現在其他 crate 的 dev-dependencies，不進生產依賴鏈。

use camino::{Utf8Path, Utf8PathBuf};
use std::fs;

/// 建立一個暫存目錄，回傳其路徑；目錄會在 `TempTree` 被 drop 時自動清除。
pub struct TempTree {
    pub root: Utf8PathBuf,
}

impl TempTree {
    pub fn new() -> Self {
        let root = std::env::temp_dir().join(format!("bkp-test-{}", uuid_like()));
        fs::create_dir_all(&root).expect("failed to create temp tree");
        Self {
            root: Utf8PathBuf::from_path_buf(root).expect("non-utf8 temp path"),
        }
    }

    /// 在暫存目錄下寫入一個檔案，會自動建立中間目錄。
    pub fn write_file(&self, rel_path: &str, content: &[u8]) -> Utf8PathBuf {
        let path = self.root.join(rel_path);
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).expect("failed to create parent dir");
        }
        fs::write(&path, content).expect("failed to write fixture file");
        path
    }
}

impl Default for TempTree {
    fn default() -> Self {
        Self::new()
    }
}

impl Drop for TempTree {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.root);
    }
}

fn uuid_like() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap()
        .as_nanos();
    format!("{nanos:x}")
}

pub fn to_utf8(p: &std::path::Path) -> Utf8PathBuf {
    Utf8Path::from_path(p).expect("non-utf8 path").to_path_buf()
}
